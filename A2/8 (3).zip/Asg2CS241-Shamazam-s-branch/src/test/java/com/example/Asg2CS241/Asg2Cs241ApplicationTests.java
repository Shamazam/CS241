package com.example.Asg2CS241;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asg2Cs241ApplicationTests {

	@Test
	void contextLoads() {
	}

}
