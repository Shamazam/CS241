package com.example.Asg2CS241.Entity;

public class StudentCourseRegistrationDTO {
    private Long studentId;
    private Long classId;

    // Getters and Setters
    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public Long getClassId() {
        return classId;
    }

    public void setClassId(Long classId) {
        this.classId = classId;
    }
}
