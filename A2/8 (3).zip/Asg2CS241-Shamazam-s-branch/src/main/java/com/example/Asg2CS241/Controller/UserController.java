package com.example.Asg2CS241.Controller;

import com.example.Asg2CS241.Entity.CourseAdmin;
import com.example.Asg2CS241.Entity.CourseInstructor;
import com.example.Asg2CS241.Entity.Parent;
import com.example.Asg2CS241.Entity.Student;
import com.example.Asg2CS241.Repository.ParentRepository;
import com.example.Asg2CS241.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UserController {

    @Autowired
    private UserService stuRepo;

    @Autowired
    private UserService parRepo;

    @Autowired
    private UserService courTeacherRepo;

    @Autowired
    private UserService courAdminRepo;

    @Autowired
    private ParentRepository parentRepo;


    @RequestMapping(value = "/save1", method = RequestMethod.POST)
    public String saveNewStudent(@ModelAttribute("Student") Student student, Model model) {
        // Check if the parent account exists
        Parent parent = parentRepo.findById(student.getParent().getParentid()).orElse(null);

        if (parent == null) {
            // If the parent account doesn't exist, add an error message to the model
            model.addAttribute("errorMessage", "Parent account does not exist. Please enter a valid parent ID.");
            return "RegisterStudent";  // Return to the registration page
        }

        // Encrypt the student's password before saving
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(student.getPassword());
        student.setPassword(encodedPassword);

        // Set the parent for the student
        student.setParent(parent);

        // Save the student
        stuRepo.save(student);

        // Redirect to the dashboard if successful
        return "redirect:/CourseAdminDashboard";
    }


    @RequestMapping(value = "/save2", method = RequestMethod.POST)
    public String saveNewParent(@ModelAttribute("Parent") Parent Parent) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(Parent.getPassword());
        Parent.setPassword(encodedPassword);

        parRepo.save(Parent);
        return "redirect:/CourseAdminDashboard";
    }

    @RequestMapping(value = "/save3", method = RequestMethod.POST)
    public String saveNewCourInstructor(@ModelAttribute("CourseInstructor") CourseInstructor CourseInstructor) {

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(CourseInstructor.getPassword());
        CourseInstructor.setPassword(encodedPassword);


        courTeacherRepo.save(CourseInstructor);
        return "redirect:/CourseAdminDashboard";
    }

    @RequestMapping(value = "/save4", method = RequestMethod.POST)
    public String saveNewCourAdmin(@ModelAttribute("CourseAdmin") CourseAdmin CourseAdmin) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(CourseAdmin.getPassword());
        CourseAdmin.setPassword(encodedPassword);

        courAdminRepo.save(CourseAdmin);
        return "redirect:/CourseAdminDashboard";
    }
}
