package com.example.Asg2CS241;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Asg2Cs241Application {

	public static void main(String[] args) {
		SpringApplication.run(Asg2Cs241Application.class, args);
	}

}
