package com.example.Asg2CS241.Controller;

import com.example.Asg2CS241.Entity.*;
import com.example.Asg2CS241.Repository.ClassRepository;
import com.example.Asg2CS241.Repository.CourseInstructorRepository;
import com.example.Asg2CS241.Repository.ParentRepository;
import com.example.Asg2CS241.Repository.StudentRepository;
import com.example.Asg2CS241.Security.CustomCourseAdminDetails;
import com.example.Asg2CS241.Security.CustomCourseInstructorDetails;
import com.example.Asg2CS241.Security.CustomParentDetails;
import com.example.Asg2CS241.Security.CustomStudentDetails;
import com.example.Asg2CS241.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.Set;


@Controller
public class SiteController {
    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String restingPage() {
        return "LoginStudent";
    }
    @GetMapping("login-student")
    public String loginStudent() {
        return "LoginStudent";
    }




    @GetMapping("/CourseAdminDashboard/register-student")
    public String showRegisterStudent(Model model) {
        model.addAttribute("Student", new Student());
        return "RegisterStudent";  // This returns the 'register.html' template
    }

    @GetMapping("/CourseAdminDashboard/register-parent")
    public String showRegisterParent(Model model) {
        model.addAttribute("Parent", new Parent());
        return "RegisterParent";  // This returns the 'register.html' template
    }

    @GetMapping("/CourseAdminDashboard/register-admin")
    public String showRegisterAdmin(Model model) {
        model.addAttribute("CourseAdmin", new CourseAdmin());
        return "RegisterAdmin";  // This returns the 'register.html' template
    }

    @GetMapping("/CourseAdminDashboard/register-instructor")
    public String showRegisterInstructor(Model model) {
        model.addAttribute("CourseInstructor", new CourseInstructor());
        return "RegisterInstructor";  // This returns the 'register.html' template
    }

    @Autowired
    private UserService stuRepo;

    @GetMapping("/StudentDashboard")
    public String showStudentDashboard(Model model) {
        // Get the currently authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomStudentDetails userDetails = (CustomStudentDetails) authentication.getPrincipal();

        // Fetch the student entity using the student ID from the user details
        Long studentId = userDetails.getId();  // Assuming CustomStudentDetails has getId()

        // Add the studentId to the model so it can be accessed in the view
        model.addAttribute("studentId", studentId);

        return "StudentDashboard";
    }

    @GetMapping("/CourseAdminDashboard")
    public String showAdminDashboard(Model model) {

        // Get the currently authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomCourseAdminDetails userDetails = (CustomCourseAdminDetails) authentication.getPrincipal();

        // Fetch the student entity using the student ID from the user details
        Long courseadminId = userDetails.getId();  // Assuming CustomStudentDetails has getId()

        // Add the studentId to the model so it can be accessed in the view
        model.addAttribute("courseAdminId", courseadminId);


        return "CourseAdminDashboard";  // Return the admin dashboard view
    }

    @GetMapping("/CourseInstructorDashboard")
    public String showInstructorDashboard(Model model) {
        // Get the currently authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomCourseInstructorDetails userDetails = (CustomCourseInstructorDetails) authentication.getPrincipal();

        // Fetch the course instructor ID from the user details
        Long courseinstructorId = userDetails.getId();

        // Add the instructor ID to the model so it can be used in the view
        model.addAttribute("courseInstructorId", courseinstructorId);

        return "CourseInstructorDashboard";  // This is your Thymeleaf template for the dashboard
    }

    @GetMapping("/ParentDashboard")
    public String showParentDashboard(Model model) {

        // Get the currently authenticated user
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        CustomParentDetails userDetails = (CustomParentDetails) authentication.getPrincipal();

        // Fetch the student entity using the student ID from the user details
        Long parentId = userDetails.getId();  // Assuming CustomStudentDetails has getId()


        // Fetch all students linked to the parent
        Set<Student> students = userService.getStudentsByParentId(parentId);
        model.addAttribute("students", students);
        model.addAttribute("parentId", parentId);



        // Add the studentId to the model so it can be accessed in the view
        model.addAttribute("parentId", parentId);





        return "ParentDashboard";  // Return the student dashboard view
    }

    @Autowired
    private UserService courseRepo;

    @GetMapping("/CourseAdminDashboard/register-course")
    public String showCourseCreatePage(Model model){
        model.addAttribute("Course", new Course());
        return "create_course";
    }

    @RequestMapping(value = "/save-course", method = RequestMethod.POST)
    public String saveCourse(@ModelAttribute("Course") Course course) {

        courseRepo.save(course);

        return "redirect:/CourseAdminDashboard";
    }

    @GetMapping("/CourseAdminDashboard/registerStudentToClass")
    public String showRegistrationForm(Model model) {
        // Add the DTO object to the model
        model.addAttribute("studentCourseRegistrationDTO", new StudentCourseRegistrationDTO());
        return "RegisterStudentToCourse";
    }

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ClassRepository classRepository;

    @PostMapping("/CourseAdminDashboard/registerStudentToClass/save")
    public String registerStudentToClass(@ModelAttribute StudentCourseRegistrationDTO registrationDTO, Model model) {
        Long studentId = registrationDTO.getStudentId();
        Long classId = registrationDTO.getClassId();

        // Validate if the student exists
        Optional<Student> student = studentRepository.findById(studentId);
        if (student.isEmpty()) {
            model.addAttribute("errorMessage", "Student ID " + studentId + " does not exist.");
            return "RegisterStudentToCourse";  // Return to the same registration page with an error message
        }

        // Validate if the class exists
        Optional<Course> classEntity = classRepository.findById(classId);
        if (classEntity.isEmpty()) {
            model.addAttribute("errorMessage", "Class ID " + classId + " does not exist.");
            return "RegisterStudentToCourse";  // Return to the same registration page with an error message
        }

        // Add the student to the class via UserService if both are valid
        userService.registerStudentToClass(studentId, classId);

        return "redirect:/CourseAdminDashboard";  // Redirect to the dashboard upon success
    }


    @GetMapping("/CourseAdminDashboard/registerInstructorToClass")
    public String showRegistrationFormInstructor(Model model) {
        // Add the DTO object to the model
        model.addAttribute("instructorCourseRegistrationDTO", new InstructorCourseRegistrationDTO());
        return "RegisterInstructorToCourse";
    }
    @Autowired
    private CourseInstructorRepository courseInstructorRepository;

    @PostMapping("/CourseAdminDashboard/registerInstructorToClass/save")
    public String registerInstructorToClass(@ModelAttribute InstructorCourseRegistrationDTO registrationDTO, Model model) {
        Long instructorId = registrationDTO.getCourseInstructorId();
        Long classId = registrationDTO.getClassId();

        // Check if the instructor exists
        Optional<CourseInstructor> instructor = courseInstructorRepository.findById(instructorId);
        if (instructor.isEmpty()) {
            model.addAttribute("errorMessage", "Instructor ID " + instructorId + " does not exist.");
            return "RegisterInstructorToCourse";  // Return to the same page with an error message
        }

        // Check if the class exists
        Optional<Course> classEntity = classRepository.findById(classId);
        if (classEntity.isEmpty()) {
            model.addAttribute("errorMessage", "Class ID " + classId + " does not exist.");
            return "RegisterInstructorToCourse";  // Return to the same page with an error message
        }

        // Register the instructor to the class via UserService if both exist
        userService.registerInstructorToClass(instructorId, classId);

        return "redirect:/CourseAdminDashboard";  // Redirect on success
    }






}
